﻿CREATE TABLE [dbo].[opetaja]
(
	[opetajaId] INT NOT NULL PRIMARY KEY IDENTITY (1,1),
	[nimi] VARCHAR (50) NULL,
	[kirjandus] VARCHAR (100) NULL
)
